

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h> //
// for fexist
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>  //define getcwd
// time 
#include <time.h>
#include <ncurses.h>



/// C based libraries (no ncurses)
#include "../libc/libc-key.c"
#include "../libc/libc-str.c"
#include "../libc/libc-bin.c"
#include "../libc/libc-string.c"
#include "../libc/libc-fileconv.c"
//#include "../libc/libc-math.c"
#include "../libc/libc-time.c"


/// C based libraries for a dialogs 
#include "../libnc/libnc-color.c"
#include "../libnc/libnc-graphic.c"
#include "../libnc/libnc-menu-msgbox.c"
#include "../libnc/libnc-time.c"

/// C based libraries (with ncurses)
#include "../libnc/libnc-bin.c"



////////////////////////////////////////////////
////////////////////////////////////////////////
////////////////////////////////////////////////
////////////////////////////////////////////////
////////////////////////////////////////////////
int main( int argc, char *argv[])
{
    int ch; 
    int foo; 
    int i, j , k ; 
    int boo; 
    int posx; 
    int posy; 
    char foocwd[PATH_MAX];
    int foostrlength;
    int ndesktop_gameover = 0;
    int nwin_x1[25];
    int nwin_x2[25];
    int nwin_y1[25];
    int nwin_y2[25];
    int nwin_show[25];
    int nwin_app[25];
    int nwin_sel[25];
    int nwin_scrolly[25];
    char nwin_file[25][PATH_MAX];
    char nwin_path[25][PATH_MAX];
    int nwinmode = 0; //fly

    for( foo = 1 ; foo <= 20 ; foo++)
    {
        nwin_x1[foo]=2+foo;
        nwin_x2[foo]=30+foo;
        nwin_y1[foo]=2+foo;
        nwin_y2[foo]=10+foo;
        nwin_show[foo]=0;
        nwin_app[foo]=0;
        nwin_sel[foo]=1;
        nwin_scrolly[foo]=0;
	strncpy( nwin_path[foo], getcwd( foocwd, PATH_MAX) , PATH_MAX);
	strncpy( nwin_file[foo], "", PATH_MAX);
    }
        



    char line[PATH_MAX];
    char linetmp[PATH_MAX];
    char cmdi[PATH_MAX];
    char filetarget[250];
    char idata[1240][250];
    char cwd[PATH_MAX];
    char pathbefore[PATH_MAX];
    strncpy( pathbefore , getcwd( cwd, PATH_MAX ) , PATH_MAX );
    unsigned filemax = 0;
    unsigned n=0;
    DIR *dirp;
    struct dirent *dp;
    int selection = 0 ; 
    int selectionmax = 0 ; 
    int scrolly=0; 
    int showhiddenfiles = 0;

//[[[  LOADLIST
   void loadlist(){
    int n = 0 ; 
    filemax = 0; 
    dirp = opendir( "." );
    strncpy( idata[ n++ ] , ".." , 250 );
    while  ((dp = readdir( dirp )) != NULL  &&  
            n < sizeof idata / sizeof idata[ 0 ]) {
            if ( strcmp( dp->d_name , "." ) != 0 )
            if ( ( showhiddenfiles == 0 ) && ( dp->d_name[0] != '.' ) )
            {
              strncpy( idata[ n++ ] , dp->d_name , 250 );
            }
    }
    filemax = n-1 ; 
    closedir( dirp );

    if ( n > 1 )
      qsort( idata, n , sizeof idata[0], compare_fun );

    for( n = 0 ; n <= filemax ; n++)
    {
       //printf( "%s\n" , idata[ n ] );
    }
    selectionmax = filemax ;
    if ( selection >= selectionmax ) selection = 0;
   }
   /////////////
   loadlist();
//]]]


    nstartncurses(  );   // <-- this will  give you F10 
    int rows, cols ;
    getmaxyx( stdscr, rows , cols);
    
    void colorblack(){ color_set( 0 , NULL ); attroff( A_BOLD ); attroff( A_REVERSE ); }
    void colorcyan(){ color_set( 6 , NULL ); attroff( A_BOLD ); attron( A_REVERSE ); }
    void colorjaune(){    colorcyan(); color_set( 3, NULL ); }


    void colorblue(){ attroff( A_BOLD ); attroff( A_REVERSE); color_set( 11 , NULL ); }
    void colorbluebold(){ attron( A_BOLD ); attroff( A_REVERSE); color_set( 11 , NULL ); }

    void colorred(){ attron( A_BOLD ); attron( A_REVERSE); color_set( 20 , NULL ); }
    void coloryellow(){ color_set( 12 , NULL ); attron( A_BOLD ); attroff( A_REVERSE ); }
    void colormenuyellow(){ color_set( 22 , NULL ); attron( A_BOLD ); attroff( A_REVERSE ); }
    void colordefault(){ attron(A_REVERSE ); attroff(A_REVERSE ); color_set( 18 , NULL ); attron( A_BOLD ); }
    void colordefaultrev(){ attron(A_REVERSE ); attroff(A_REVERSE ); color_set( 18 , NULL ); attroff( A_BOLD ); }



//[[[TINYPAGER
  ///////// tinypager_draw
  char getlinestring[PATH_MAX];
  char currentline[PATH_MAX];
  int tinypager_show_basename = 0 ;
  int x1, x2, y1, y2;
  int tinypager_view_tabselect = 0;
  char tinypager_filesource[PATH_MAX];
  int tinypager_linesel = 0;
  int tinypager_scrolly = 0;
  int posxcounter = 0 ;
  int tinypager_linemax = 0;
  int tinypager_view_scrollx = 0;
  int tinypager_view_selectline = 0;
  FILE *fp;
  void tinypager_draw( ){
     strncpy( getlinestring, "", PATH_MAX );
     strncpy( currentline , "" , PATH_MAX );

     if ( tinypager_view_tabselect < 0 )
        tinypager_view_tabselect = 0 ;

     if ( tinypager_view_selectline < 0 ) tinypager_view_selectline = 0 ; 
     if ( tinypager_scrolly <= 0 ) tinypager_scrolly = 0;
     if ( tinypager_linesel <= 0 ) tinypager_linesel = 0;

         posxcounter = 0 ;
	 colorblue();
         tinypager_linemax = 0;
          
	 posx = x1 ;
         if (  fexist( tinypager_filesource ) == 1) 
         {
         fp = fopen( tinypager_filesource , "rb" ) ; 
	    posy = y1 ; 
            posxcounter = 0 ;
            while (( posy <= y2 ) && 
	      (!feof(fp)) ) {

	       // gets full line normally
               fgets(linetmp, PATH_MAX , fp ); 
	       if ( tinypager_show_basename == 1 )
	          strncpy( line , fbasename(linetmp),  PATH_MAX );
	       else
	          strncpy( line , linetmp,  PATH_MAX );
               tinypager_linemax++;

            colorblue();


           ///////////////////////
           if ( tinypager_linemax >= tinypager_scrolly ){
	    
            if ( tinypager_view_selectline >= 1 )
            if (  tinypager_linemax ==  tinypager_view_selectline )
            if (!feof(fp))
	    {
	       strncpy( getlinestring, strrlf(line), PATH_MAX );
	       attron( A_REVERSE );
	    }

             if (!feof(fp))
	     for ( i = 0 ; ( i <= strlen( line )); i++)
	          { 
		    if ( posx - tinypager_view_scrollx <= x2-1 )
		    if ( line[i] != '\r' ) 
		      if ( line[i] != '\n' ) 
		      {
                       if (  posxcounter >= tinypager_view_scrollx )   

	               mvprintw( posy , posx - tinypager_view_scrollx , "%c" , line[i] );
		       posx++;
                       posxcounter++;
		      }
		  }
		  posy++;
		  posx = x1;
                  posxcounter = 0 ;

            }
	   }
         fclose( fp );
	 }
         attroff( A_REVERSE );
         attroff( A_BOLD );
    }
//]]]























    int winsel = 1;
    while( ndesktop_gameover == 0 )
    {

    if ( nwin_sel[winsel] <= 0 ) nwin_sel[winsel] = 0;
    if ( nwin_scrolly[winsel] <= 0 ) nwin_scrolly[winsel] = 0;

    colordefaultrev();
    ncerase();
    colormenuyellow();
    nchspace( 0, 0, cols-1 );
    mvprintw( 0, 0, "|NDESKTOP|" );
    nchspace( rows-1, 0, cols-1 );

    colordefaultrev();
    attroff( A_REVERSE);
    color_set( 0, NULL );
    for( foo = 1 ; foo <= rows-2 ; foo++)
      nchchar( foo, 0, cols-1 , ' ' );

    colormenuyellow();
    mvprintw( rows-1, cols-1 -10, "%s", strtimenow() );
    mvprintw( rows-1,0, "|%d|" , winsel );
    if ( nwin_app[winsel] == 1 )
       printw( "[Tree]" );
    else if ( nwin_app[winsel] == 2 )
       printw( "[Reader]" );



    attroff( A_BOLD );
    for( foo = 1 ; foo <= 20 ; foo++)
    {
	strncpy( tinypager_filesource, "" , PATH_MAX );


        if ( nwin_show[foo] == 1 )
	{
              attron( A_REVERSE); color_set( 0, NULL );
	      ncrectangle(   nwin_y1[foo], nwin_x1[foo], nwin_y2[foo], nwin_x2[foo] );
	      ncframe( nwin_y1[foo], nwin_x1[foo], nwin_y2[foo], nwin_x2[foo] );
	      mvprintw( nwin_y1[foo], nwin_x1[foo]+2, "[" );
	      if ( foo == winsel ) 
               if ( nwinmode == 0 ) //fly 
	          addch( ACS_BULLET ); 
               else if ( nwinmode == 1 ) //active tree
	          addch( ACS_DIAMOND ); 
	      else if ( foo != winsel ) addch( ' ' ); 
	      printw( "%d]", foo );


	      if ( nwin_app[ foo ] == 1 )
	      {
	        chdir( nwin_path[ foo ] );
                loadlist();
	        attron( A_REVERSE );
                for( boo = 1 ; boo <= filemax ; boo++)
		{
		  if ( boo >= nwin_scrolly[ foo ] )
		    posy = nwin_y1[foo]+boo - nwin_scrolly[ foo ]  ; 

	          attron( A_REVERSE );
		  foostrlength = nwin_x2[foo] - nwin_x1[foo] -1 ;
		  if ( nwin_sel[ foo ] == boo  ) attroff( A_REVERSE );

		  if ( boo >= nwin_scrolly[ foo ] )
		   if ( posy <= nwin_y2[foo] -1 )
		    if ( posy >= nwin_y1[ foo ]+1 )
	             mvprintw( posy,  nwin_x1[foo]+1, "%s", strcut( idata[ boo ], 1,  foostrlength )  );
		}
	      }


	      if ( nwin_app[ foo ] == 2 )
	      {
	          chdir( nwin_path[ foo ] );
	          colorblue();
	          ncrectangle( nwin_y1[foo]+1, nwin_x1[foo]+1, nwin_y2[foo]-1, nwin_x2[foo]-1);
		  attroff( A_BOLD );
		  tinypager_scrolly = nwin_sel[foo] ;
	          strncpy( tinypager_filesource, nwin_file[foo] , PATH_MAX );
                  x1 = nwin_x1[foo]+1 ; 
                  y1 = nwin_y1[foo]+1 ; 
                  x2 = nwin_x2[foo]-1 ; 
                  y2 = nwin_y2[foo]-1 ; 
		  if ( strcmp( tinypager_filesource, "" ) != 0 )
	              tinypager_draw();
		  attroff( A_BOLD );
	      }


	}
    }


    refresh();
    ch = getch();


      if ( nwinmode == 1 )         //active edit
      if ( nwin_app[winsel] == 2 ) //tree
      switch( ch ){
           case 'j':
              nwin_sel[winsel]++;
	      break;
           case 'k':
              nwin_sel[winsel]--;
	      break;
           case 'i':
              nwinmode = 0; 
	      break;
           case 'g':
              nwin_sel[winsel] = 1;
	      break;
           case KEY_GBACKSPACE:
              chdir( ".." );
	      strncpy( nwin_path[winsel], getcwd( foocwd, PATH_MAX) , PATH_MAX);
	      break;
      }



      if ( nwinmode == 1 )         //active edit
      if ( nwin_app[winsel] == 1 ) //tree
      switch( ch ){
           case 'j':
              nwin_sel[winsel]++;
	      break;
           case 'k':
              nwin_sel[winsel]--;
	      break;
           case 'i':
              nwinmode = 0; 
	      break;
           case 'g':
              nwin_sel[winsel] = 1;
	      break;
           case KEY_GBACKSPACE:
              chdir( ".." );
	      strncpy( nwin_path[winsel], getcwd( foocwd, PATH_MAX) , PATH_MAX);
	      break;
      }



     
      if ( nwinmode == 0 ) // fly
      switch( ch ){
           case 'Q':
           case KEY_GFUNCF10:
	      ndesktop_gameover = 1;
	      break;

           case '1':
           case '2':
           case '3':
           case '4':
           case '5':
           case '6':
           case '7':
           case '8':
           case '9':
              nwin_show[ch - 48] = 1;
              winsel = ch - 48;
	      break;

           case KEY_GPAGEUP:
              nwin_scrolly[winsel]--;
	      break;
           case KEY_GPAGEDOWN:
              nwin_scrolly[winsel]++;
	      break;
           case 'k':
              nwin_sel[winsel]--;
	      break;
           case 'j':
              nwin_sel[winsel]++;
	      break;

           case KEY_GCTRLU:
	   case 'u':
              if ( nwin_app[winsel] >= 1 )
	      if ( winsel >= 1 )
	      {
               nwin_scrolly[winsel]-=4;
               nwin_sel[winsel]-=4;
	      }
	      break;
	   case 'd':
           case KEY_GCTRLD:
              if ( nwin_app[winsel] >= 1 )
	      if ( winsel >= 1 )
	      {
               nwin_scrolly[winsel]+=4;
               nwin_sel[winsel]+=4;
	      }
	      break;

           case 'g':
              colormenuyellow();
              mvprintw( rows-1, cols-3, "[g]" );
	      ch = getch();
	      if ( ch == 'g' )
	      {
               nwin_sel[winsel] = 1;
	       nwin_scrolly[winsel] = 0;
	      }
	      break;

           case '0':
              nwin_show[winsel] = 0;
	      break;

           case KEY_RIGHT:
              nwin_x1[winsel]++;
              nwin_x2[winsel]++;
	      break;
           case KEY_LEFT:
              nwin_x1[winsel]--;
              nwin_x2[winsel]--;
	      break;
           case KEY_DOWN:
              nwin_y1[winsel]++;
              nwin_y2[winsel]++;
	      break;
           case KEY_UP:
              nwin_y1[winsel]--;
              nwin_y2[winsel]--;
	      break;


           case 'L':
              nwin_x2[winsel]++;
	      break;
           case 'H':
              nwin_x2[winsel]--;
	      break;
           case 'J':
              nwin_y2[winsel]++;
	      break;
           case 'K':
              nwin_y2[winsel]--;
	      break;


           case 't':
              nwin_app[winsel] = 1; 
              nwinmode = 0;
	      break;


           case 'm':
                colormenuyellow();
                mvprintw( rows-1, cols-3, "[m]" );
	        ch = getch();
	        if ( ch == 'g' )
		{
	         foo = winsel; 
                 nwin_x1[foo]=2;
                 nwin_x2[foo]=20;
                 nwin_y1[foo]=2;
                 nwin_y2[foo]=15;
	        }
	      else if ( ch == 'm')
		{
	         foo = winsel; 
                 nwin_x1[foo]=0;
                 nwin_x2[foo]=cols-1;
                 nwin_y1[foo]=1;
                 nwin_y2[foo]=rows-2;
	        }
	        break;

           case KEY_GBACKSPACE:
	   case 'h':
              chdir( ".." );
	      strncpy( nwin_path[winsel], getcwd( foocwd, PATH_MAX) , PATH_MAX);
	      break;

	   case 'l':
	      foo = nwin_sel[winsel]; 
	      if ( fexist( idata[ foo ] ) == 2 )
                    chdir( idata[ foo ] );
	      strncpy( nwin_path[winsel], getcwd( foocwd, PATH_MAX) , PATH_MAX);
	      break;

           case 'r':
              nwin_app[winsel] = 2; 
              nwinmode = 0;
	      foo = nwin_sel[winsel]; 
	      strncpy(nwin_file[ winsel ], idata[ foo ] , PATH_MAX );
              nwin_sel[winsel] = 1; 
	      break;

      }

    }

    curs_set( 1 ) ;
    attroff( A_BOLD );
    attroff( A_REVERSE );
    curs_set( 1 );
    endwin();			/* End curses mode		  */
    return 0;
}


